﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Traverser.Quests
{
    public partial class frmQuests_PointOnLine : Form
    {
        public frmQuests_PointOnLine()
        {
            InitializeComponent();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            //netFteo.BaseClasess.Geodethic.DivideLine
        }
    }
}
